import React, { Component } from 'react';
import { Link } from 'react-router-dom';



class Video extends Component {

    render() {
        return (
            <section>

            </section>
        );
    }
}

export default Video;