import React, { Component } from 'react';



class Video extends Component {

    render() {
        return (
            <section >

            </section>
        );
    }
}

export default Video;