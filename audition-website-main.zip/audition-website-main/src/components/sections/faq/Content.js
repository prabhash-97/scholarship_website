import React, { Component, Fragment } from 'react';

import Faqs from './Faqs';

class Content extends Component {
    render() {
        return (
            <Fragment>
                <Faqs/>
            </Fragment>
        );
    }
}

export default Content;