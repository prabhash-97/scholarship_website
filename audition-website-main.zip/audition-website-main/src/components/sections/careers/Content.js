import React, { Component, Fragment } from 'react';
import Joblist from './Joblist';

class Content extends Component {
    render() {
        return (
            <Fragment>
                <Joblist/>
            </Fragment>
        );
    }
}

export default Content;